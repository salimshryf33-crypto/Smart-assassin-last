--
-- PostgreSQL database dump
--

\restrict yTQVrJp7XzO2oSRnh4DXN4y0ePs425p1f0ebp56LQoJS10apkZ9RxgzZIARpZvq

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    uid text,
    action text NOT NULL,
    resource_type text,
    resource_id text,
    metadata jsonb,
    ip_address text,
    request_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: db_backup_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.db_backup_log (
    id integer NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    status text DEFAULT 'running'::text NOT NULL,
    file_path text,
    file_size_kb integer,
    error_message text,
    verified boolean DEFAULT false NOT NULL,
    backup_data bytea,
    CONSTRAINT db_backup_log_status_check CHECK ((status = ANY (ARRAY['running'::text, 'success'::text, 'failed'::text])))
);


ALTER TABLE public.db_backup_log OWNER TO postgres;

--
-- Name: db_backup_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.db_backup_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.db_backup_log_id_seq OWNER TO postgres;

--
-- Name: db_backup_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.db_backup_log_id_seq OWNED BY public.db_backup_log.id;


--
-- Name: exam_answers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_answers (
    id text NOT NULL,
    attempt_id text NOT NULL,
    question_id text NOT NULL,
    student_answer text,
    is_correct boolean,
    grading_method text DEFAULT 'pending'::text,
    ai_feedback text,
    answered_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exam_answers OWNER TO postgres;

--
-- Name: exam_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_attempts (
    id text NOT NULL,
    exam_id text NOT NULL,
    student_id text NOT NULL,
    status text DEFAULT 'in_progress'::text NOT NULL,
    total_questions integer DEFAULT 0,
    correct_count integer DEFAULT 0,
    score_pct numeric(5,2),
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.exam_attempts OWNER TO postgres;

--
-- Name: exam_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_questions (
    id text NOT NULL,
    exam_id text NOT NULL,
    question text NOT NULL,
    question_type text DEFAULT 'mcq'::text NOT NULL,
    options jsonb,
    correct_answer text,
    explanation text,
    topic text,
    chapter text,
    subject text NOT NULL,
    grade text NOT NULL,
    country text NOT NULL,
    year text,
    exam_type text,
    difficulty text,
    organization text,
    source_exam_id text NOT NULL,
    source_exam_title text NOT NULL,
    question_order integer,
    extracted_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.exam_questions OWNER TO postgres;

--
-- Name: exam_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_records (
    exam_id text NOT NULL,
    curriculum_doc_id text NOT NULL,
    title text NOT NULL,
    book_title text,
    subject text NOT NULL,
    grade text NOT NULL,
    country text NOT NULL,
    track text,
    year text,
    exam_type text DEFAULT 'final'::text NOT NULL,
    organization text,
    owner_id text,
    visibility text DEFAULT 'private'::text NOT NULL,
    question_count integer DEFAULT 0,
    extraction_status text DEFAULT 'pending'::text NOT NULL,
    extraction_error text,
    extracted_at timestamp with time zone,
    ocr_quality_score integer,
    extraction_attempts integer,
    failure_reason text,
    ocr_diagnostics jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exam_records OWNER TO postgres;

--
-- Name: pdf_upload_hashes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pdf_upload_hashes (
    sha256 text NOT NULL,
    doc_id text NOT NULL,
    owner_id text,
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pdf_upload_hashes OWNER TO postgres;

--
-- Name: rate_limit_buckets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rate_limit_buckets (
    id text NOT NULL,
    tokens real DEFAULT 0 NOT NULL,
    last_refill_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rate_limit_buckets OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    uid text NOT NULL,
    role text NOT NULL,
    granted_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT user_roles_role_check CHECK ((role = ANY (ARRAY['student'::text, 'teacher'::text, 'moderator'::text, 'admin'::text, 'super_admin'::text])))
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: weakness_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.weakness_snapshots (
    id integer NOT NULL,
    student_id text NOT NULL,
    country text NOT NULL,
    grade text NOT NULL,
    subject text NOT NULL,
    topic_scores jsonb DEFAULT '{}'::jsonb NOT NULL,
    total_exams integer DEFAULT 0,
    last_updated timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.weakness_snapshots OWNER TO postgres;

--
-- Name: weakness_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.weakness_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.weakness_snapshots_id_seq OWNER TO postgres;

--
-- Name: weakness_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.weakness_snapshots_id_seq OWNED BY public.weakness_snapshots.id;


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: db_backup_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_backup_log ALTER COLUMN id SET DEFAULT nextval('public.db_backup_log_id_seq'::regclass);


--
-- Name: weakness_snapshots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weakness_snapshots ALTER COLUMN id SET DEFAULT nextval('public.weakness_snapshots_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, uid, action, resource_type, resource_id, metadata, ip_address, request_id, created_at) FROM stdin;
1	JlLBDDgQpkRtgJ3efZ8Lp7yhijr2	backup_run	\N	\N	\N	102.45.76.48	060ce6a4-2b84-4b93-b02f-b4dea1ba79e2	2026-06-23 12:54:52.568671+00
\.


--
-- Data for Name: db_backup_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.db_backup_log (id, started_at, finished_at, status, file_path, file_size_kb, error_message, verified, backup_data) FROM stdin;
1	2026-06-23 12:54:52.568881+00	\N	running	/home/runner/workspace/artifacts/api-server/data/backups/sage-backup-2026-06-23T12-54-52.sql.gz	\N	\N	f	\N
\.


--
-- Data for Name: exam_answers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_answers (id, attempt_id, question_id, student_answer, is_correct, grading_method, ai_feedback, answered_at) FROM stdin;
\.


--
-- Data for Name: exam_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_attempts (id, exam_id, student_id, status, total_questions, correct_count, score_pct, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: exam_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_questions (id, exam_id, question, question_type, options, correct_answer, explanation, topic, chapter, subject, grade, country, year, exam_type, difficulty, organization, source_exam_id, source_exam_title, question_order, extracted_at) FROM stdin;
732fef6f-3588-45f2-b79d-97bc5cc4aefd	1d6bff6c-781b-4679-ac95-648f9ca208f9	المعايرة هي العملية التي يتم فيها تفاعل محلول ....	short_answer	\N	\N	\N	المعايرة	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	1	2026-06-23 11:16:51.447365+00
bb3e32cf-0a6d-4df9-8bde-7653799729a6	1d6bff6c-781b-4679-ac95-648f9ca208f9	الكتلة الموليّة من كل فلز ؟	calculation	\N	\N	\N	الكتلة المولية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	2	2026-06-23 11:16:51.447365+00
0df75727-574a-4e99-830d-e771801bb12a	1d6bff6c-781b-4679-ac95-648f9ca208f9	أربعة عوامل تؤثر في معدل ( سرعة ) التفاعل الكيميائي ، أذكرها :	short_answer	\N	\N	\N	معدل التفاعل الكيميائي	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	3	2026-06-23 11:16:51.447365+00
8b9130b2-22a4-4a5c-967e-aaa95d1ddca3	1d6bff6c-781b-4679-ac95-648f9ca208f9	اكتب قانون معدل ( سرعة ) تغير تركيز البروم في التفاعل .	short_answer	\N	\N	\N	معدل التفاعل الكيميائي	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	4	2026-06-23 11:16:51.447365+00
952ddf00-50b8-4b63-bec1-765c26d8d8f7	1d6bff6c-781b-4679-ac95-648f9ca208f9	احسب معدل ( سرعة ) التفاعل في الفترة الزمنية المذكورة .	calculation	\N	\N	\N	معدل التفاعل الكيميائي	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	5	2026-06-23 11:16:51.447365+00
f3a35d88-824a-41b6-8faa-c33d1491d019	1d6bff6c-781b-4679-ac95-648f9ca208f9	عبر رياضياً عن معدل ( سرعة ) التفاعل باستخدام قانون فعل الكتلة .	short_answer	\N	\N	\N	قانون فعل الكتلة	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	6	2026-06-23 11:16:51.447365+00
4f0959a9-3ad5-43fd-8c7e-f78365491660	1d6bff6c-781b-4679-ac95-648f9ca208f9	اكتب معادلة كيميائية موزونة تمثل التفاعل الذي يحدث .	short_answer	\N	\N	\N	تحضير الإيثاين	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	7	2026-06-23 11:16:51.447365+00
c86d7a23-8ded-438d-aaec-9cbbc2e61374	1d6bff6c-781b-4679-ac95-648f9ca208f9	اكتب معادلة كيميائية تمثل تفاعلاً يقود لتكوين ثلاثي جليسريد مبتدئاً بالجليسرول ( الجلسرين ) وحمض الاستياريك ذي الصيغة : CH3 (CH2)16 – COOH	short_answer	\N	\N	\N	تكوين ثلاثي جليسريد	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	8	2026-06-23 11:16:51.447365+00
005f8bdd-85fa-46b4-aa58-83bcf16b1ed9	1d6bff6c-781b-4679-ac95-648f9ca208f9	الناتج من تفاعل .	short_answer	\N	\N	\N	تفاعلات كيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	9	2026-06-23 11:16:51.447365+00
9f567c7b-e580-400d-ae0f-2c8821047b17	1d6bff6c-781b-4679-ac95-648f9ca208f9	ما هو الاختلاف الأساس بين الشحوم والزيوت ؟	short_answer	\N	\N	\N	الشحوم والزيوت	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	10	2026-06-23 11:16:51.447365+00
2a869dbe-909b-4160-beb0-fa44dc902b78	1d6bff6c-781b-4679-ac95-648f9ca208f9	ما حجم محلول حمض النتريك HNO3 ذي التركيز 0.10 مول / دم3 الذي يحتوي على 31.5 جم من حمض النتريك النقي ؟ ( الكتلة الجزيئية النسبية لـ HNO3 = 63.0 ) .	calculation	\N	\N	\N	التركيز والحجم	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	11	2026-06-23 11:16:51.447365+00
3aca2577-0e53-4999-8718-c7886364946e	1d6bff6c-781b-4679-ac95-648f9ca208f9	تتكون الطاقة الكيميائية المخزونة في المادة من :	short_answer	\N	\N	\N	الطاقة الكيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	12	2026-06-23 11:16:51.447365+00
854ae0b3-bfe7-416e-ba9a-b0a6a32ab029	1d6bff6c-781b-4679-ac95-648f9ca208f9	احسب حرارة	calculation	\N	\N	\N	حرارة التفاعل	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	13	2026-06-23 11:16:51.447365+00
c8432e2b-70ca-4a92-a49e-3427e8dbb475	1d6bff6c-781b-4679-ac95-648f9ca208f9	أكمل المعادلة التالية وسم الناتج : C – H + HBr | H3C	short_answer	\N	\N	\N	تفاعلات عضوية	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	14	2026-06-23 11:16:51.447365+00
00e18615-1c29-410c-9bda-22f6651a252b	1d6bff6c-781b-4679-ac95-648f9ca208f9	الكحولات A , B , C لها نفس الصيغة الجزيئية C6H10O. جزيئات الكحول (A) تحتوي على سلسلة كربونية متفرعة ويمكن أن يتأكسد إلى ألدهيد. اكتب الصيغة البنائية للكحول (A).	short_answer	\N	\N	\N	كيمياء عضوية	\N	chemistry	grade12	sudan	\N	final	hard	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	15	2026-06-23 11:16:51.447365+00
893b15af-33be-4028-96cf-6c5a9cbae06d	1d6bff6c-781b-4679-ac95-648f9ca208f9	الكحولات A , B , C لها نفس الصيغة الجزيئية C6H10O. جزيئات الكحول (B) لها سلسلة كربونية مستقيمة ويمكن أن يتأكسد إلى كيتون. اكتب الصيغة البنائية للكحول (B).	short_answer	\N	\N	\N	كيمياء عضوية	\N	chemistry	grade12	sudan	\N	final	hard	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	16	2026-06-23 11:16:51.447365+00
06621fd7-7e0f-4dbf-8594-a987bda5b953	1d6bff6c-781b-4679-ac95-648f9ca208f9	الكحولات A , B , C لها نفس الصيغة الجزيئية C6H10O. الكحول (C) لا يتأكسد إلى ألدهيد أو كيتون. اكتب الصيغة البنائية للكحول (C).	short_answer	\N	\N	\N	كيمياء عضوية	\N	chemistry	grade12	sudan	\N	final	hard	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	17	2026-06-23 11:16:51.447365+00
56e81a68-a5ea-46d8-984a-fbc69bbf3b68	1d6bff6c-781b-4679-ac95-648f9ca208f9	يمكن تحضير كلوروايثين بإمرار كلوروايثان على نحاس ساخن لدرجة 250° مئوية. اكتب معادلة كيميائية توضح التفاعل الذي يحدث.	short_answer	\N	\N	\N	كيمياء عضوية	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	18	2026-06-23 11:16:51.447365+00
723dac4b-a291-4225-8aec-3230fa61b3e3	1d6bff6c-781b-4679-ac95-648f9ca208f9	يحضر البوليمر بولي كلوروايثين ( PVC ) من الكلوروايثين. اكتب صيغة تمثل جزء من جزيء بولي كلوروايثين.	short_answer	\N	\N	\N	كيمياء البوليمرات	\N	chemistry	grade12	sudan	\N	final	easy	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	19	2026-06-23 11:16:51.447365+00
b7a91d56-68a1-46c4-ba82-4d19ffc434ba	1d6bff6c-781b-4679-ac95-648f9ca208f9	ما هو المفاعل الذي تستخدمه لإجراء تفاعل إضافة مع المركب CH3 – CH2 = CH2 لتحضير المركب C3H7Br ؟	short_answer	\N	\N	\N	كيمياء عضوية	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	20	2026-06-23 11:16:51.447365+00
80f22f4a-a178-4478-8727-120f54604fdf	1d6bff6c-781b-4679-ac95-648f9ca208f9	في التفاعل : HBr + NH3 —> NH4+ + Br-، اختر العبارة الصحيحة.	mcq	["NH3 قاعده لأنه يمكن أن يستقبل بروتوناً.", "HBr حمض لأنه يمكن أن يستقبل بروتوناً.", "NH4+ هو القاعدة المرافقة لـ HBr.", "Br- هو الحمض المرافق لـ HBr."]	NH3 قاعده لأنه يمكن أن يستقبل بروتوناً.	\N	أحماض وقواعد	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	21	2026-06-23 11:16:51.447365+00
2925c00e-bcf7-44a1-aa5f-17163f279ca1	1d6bff6c-781b-4679-ac95-648f9ca208f9	صنف المواد في القائمة التالية إلى إلكتروليتات ولا إلكتروليتات: مصهور CuCl2، محلول السكر في الماء، NaCl، أملاح الفطر.	short_answer	\N	\N	\N	إلكتروليتات	\N	chemistry	grade12	sudan	\N	final	easy	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	22	2026-06-23 11:16:51.447365+00
40d858a1-952f-4081-9d9c-5e8e96adae65	1d6bff6c-781b-4679-ac95-648f9ca208f9	مر تيار مباشر ثابت شدته 0.01 أمبير خلال محلول أحد أملاح الفلز (M) لمدة 5 ساعات فترسب 0.030 جم من الفلز (M) عند المهبط. إذا كانت الشحنة التي يحملها أيون الفلز (M) تساوي +3، كم تكون الكتلة الذرية النسبية للفلز (M) ؟	calculation	\N	\N	\N	كيمياء كهربائية	\N	chemistry	grade12	sudan	\N	final	hard	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	23	2026-06-23 11:16:51.447365+00
5381689c-1178-4ee4-a44b-f8b127e403a2	1d6bff6c-781b-4679-ac95-648f9ca208f9	بناءً على المعايرة التالية: 25.0 سم3 من محلول حمض الهيدروكلوريك تمت معايرتها بـ 20.0 سم3 من محلول كربونات الصوديوم تركيزه 0.15 مول/دم3. معادلة التفاعل: Na2CO3 + 2HCl —> 2NaCl + H2O + CO2. كم يكون تركيز محلول حمض الهيدروكلوريك بالمول/دم3؟	calculation	\N	\N	\N	معايرة	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	24	2026-06-23 11:16:51.447365+00
920a07e7-4f79-4a1b-a301-5707dc0fc015	1d6bff6c-781b-4679-ac95-648f9ca208f9	16.0 سم3 من محلول KMnO4 0.13 م تؤكسد 20.0 سم3 من محلول FeSO4 في وسط حمضي. المعادلة الأيونية للتفاعل: 5Fe2+ + MnO4- + 8H+ —> 5Fe3+ + Mn2+ + 4H2O. احسب تركيز محلول FeSO4 بالمول/دم3.	calculation	\N	\N	\N	معايرة أكسدة-اختزال	\N	chemistry	grade12	sudan	\N	final	hard	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	25	2026-06-23 11:16:51.447365+00
71292eb0-354b-4aed-938c-222a29fafd9a	1d6bff6c-781b-4679-ac95-648f9ca208f9	في التفاعل الكيميائي الذي يتم في عدة خطوات بمعدلات مختلفة، ما هي الخطوة التي تحدد معدل (سرعة) التفاعل؟	short_answer	\N	\N	\N	حركية التفاعل	\N	chemistry	grade12	sudan	\N	final	easy	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	26	2026-06-23 11:16:51.447365+00
f1224b58-a725-4bbd-bf80-4fda24ba7b87	1d6bff6c-781b-4679-ac95-648f9ca208f9	عرف جهد القطب القياسي.	short_answer	\N	\N	\N	كيمياء كهربائية	\N	chemistry	grade12	sudan	\N	final	easy	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	27	2026-06-23 11:16:51.447365+00
31e18eb3-fb74-46bf-9974-5491c5a22949	1d6bff6c-781b-4679-ac95-648f9ca208f9	عرف الكولوم.	short_answer	\N	\N	\N	كيمياء كهربائية	\N	chemistry	grade12	sudan	\N	final	easy	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	28	2026-06-23 11:16:51.447365+00
2eb28a86-b2fc-4ad4-a10f-ce54f36b2273	1d6bff6c-781b-4679-ac95-648f9ca208f9	بناءً على تفاعل الأكسدة – الاختزال التالي: NO3-(aq) + H+(aq) + SO3^2-(aq) —> SO4^2-(aq) + HNO2(aq). اكتب نصف تفاعل الأكسدة.	short_answer	\N	\N	\N	أكسدة واختزال	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	29	2026-06-23 11:16:51.447365+00
6cdacdc7-0a5e-403a-aaf9-dd1ae1cb5164	1d6bff6c-781b-4679-ac95-648f9ca208f9	حدد غرفة كل من نصفي التفاعل: نصف الأكسدة في الغرفة (....) ونصف الاختزال في الغرفة (....)	short_answer	\N	\N	\N	الخلايا الكهروكيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	30	2026-06-23 11:16:51.447365+00
6302468b-9296-4664-bc06-c1f42ee46af4	1d6bff6c-781b-4679-ac95-648f9ca208f9	أي القطبين يكون سالب الشحنة وأيهما موجب الشحنة؟	short_answer	\N	\N	\N	الخلايا الكهروكيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	31	2026-06-23 11:16:51.447365+00
deed8555-ee1d-4d63-9a6c-4adec4921b97	1d6bff6c-781b-4679-ac95-648f9ca208f9	القطب في الغرفة (....) سالب الشحنة.	short_answer	\N	\N	\N	الخلايا الكهروكيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	32	2026-06-23 11:16:51.447365+00
2aa3b12a-6790-4c41-a6b3-45c1e1d94eb8	1d6bff6c-781b-4679-ac95-648f9ca208f9	القطب في الغرفة (....) موجب الشحنة.	short_answer	\N	\N	\N	الخلايا الكهروكيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	33	2026-06-23 11:16:51.447365+00
47850a21-f61c-4a69-b0ee-606ade639cdd	1d6bff6c-781b-4679-ac95-648f9ca208f9	مستعيناً بالمعادلات الكيميائية اذكر ما تشاهد ثم اكتب المعادلة الكيميائية التي تمثل ما شاهدته. وضح كيف تميز معملياً بين الإيثان CH3 – CH3 والإيثين CH2 = CH2 بكاشف البروم Br2.	short_answer	\N	\N	\N	الكيمياء العضوية - التمييز بين المركبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	34	2026-06-23 11:16:51.447365+00
e4d40563-7ffa-44d7-90bc-7dc458649ee4	1d6bff6c-781b-4679-ac95-648f9ca208f9	مستعيناً بالمعادلات الكيميائية اذكر ما تشاهد ثم اكتب المعادلة الكيميائية التي تمثل ما شاهدته. وضح كيف تميز معملياً بين حمض إيثانويك CH3COOH وإستر إيثانوات الميثيل CH3COOCH3 مستخدماً فلز الصوديوم Na.	short_answer	\N	\N	\N	الكيمياء العضوية - التمييز بين المركبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	35	2026-06-23 11:16:51.447365+00
71a11d64-c71f-4e59-aa83-e21d9684f564	1d6bff6c-781b-4679-ac95-648f9ca208f9	مستعيناً بالمعادلات الكيميائية اذكر ما تشاهد ثم اكتب المعادلة الكيميائية التي تمثل ما شاهدته. وضح كيف تميز معملياً بين الهكسين -1 CH2 = CH – CH2 – CH2 – CH2 – CH3 والبروم بإضافة البروم Br2.	short_answer	\N	\N	\N	الكيمياء العضوية - التمييز بين المركبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	36	2026-06-23 11:16:51.447365+00
d5190e9e-f599-4d73-85d8-b8df6e0fbf01	1d6bff6c-781b-4679-ac95-648f9ca208f9	للصيغة العضوية C6H5Br متشاكآن (أيزوميران)، اكتب الصيغة البنائية لكل منهما، وحدد نوع التشاكب بينهما.	short_answer	\N	\N	\N	الكيمياء العضوية - المتشاكبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	37	2026-06-23 11:16:51.447365+00
8e5fad08-993e-471f-aee2-7d6be5d047ba	1d6bff6c-781b-4679-ac95-648f9ca208f9	صيغة متشاكب (١):	short_answer	\N	\N	\N	الكيمياء العضوية - المتشاكبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	38	2026-06-23 11:16:51.447365+00
0bddb8f6-48a8-4e44-98ee-e4f4f15a38a5	1d6bff6c-781b-4679-ac95-648f9ca208f9	صيغة متشاكب (٢):	short_answer	\N	\N	\N	الكيمياء العضوية - المتشاكبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	39	2026-06-23 11:16:51.447365+00
31985349-2eb8-465e-af6a-75ceb998d1ff	1d6bff6c-781b-4679-ac95-648f9ca208f9	نوع التشاكب بينهما:	short_answer	\N	\N	\N	الكيمياء العضوية - المتشاكبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	40	2026-06-23 11:16:51.447365+00
0bab7861-c64c-4846-a74d-68846e764f62	1d6bff6c-781b-4679-ac95-648f9ca208f9	للتفاعل 2A + 2B —> C، إذا كان معدل (سرعة) التفاعل يساوي 1.75 × 10^-5 مول / دم3 .ث بالنسبة لاستهلاك المادة (A)، كم يكون معدل تكون (C)؟	calculation	\N	\N	\N	سرعة التفاعل الكيميائي	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	41	2026-06-23 11:16:51.447365+00
c94a393a-a454-49e1-9685-f6a32f09a50c	1d6bff6c-781b-4679-ac95-648f9ca208f9	ماذا يقصد بالعامل الحفاز؟	short_answer	\N	\N	\N	الحفز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	42	2026-06-23 11:16:51.447365+00
00758bd5-7090-4e58-b968-b4af9e61570d	1d6bff6c-781b-4679-ac95-648f9ca208f9	ما هو الحفز المتجانس؟	short_answer	\N	\N	\N	الحفز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	43	2026-06-23 11:16:51.447365+00
6be32630-355b-457d-b458-620b97a60add	1d6bff6c-781b-4679-ac95-648f9ca208f9	العامل الحفاز هو:	short_answer	\N	\N	\N	الحفز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	44	2026-06-23 11:16:51.447365+00
d9c8e749-7bf5-4f81-9330-a738223ef11c	1d6bff6c-781b-4679-ac95-648f9ca208f9	الحفز المتجانس هو:	short_answer	\N	\N	\N	الحفز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	45	2026-06-23 11:16:51.447365+00
bdef546c-9b61-4bb2-93d4-a16bda4e8b95	1d6bff6c-781b-4679-ac95-648f9ca208f9	2.56 جم من الميثانول CH3OH أذيبت في الماء، وأكمل حجم المحلول إلى 100 سم3. كثافة المحلول = 0.90 جم/سم3. كم يكون تركيز المحلول بالمول / دم3؟ (الكتلة الجزيئية لـ CH3OH = 32)	calculation	\N	\N	\N	المحاليل - التركيز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	46	2026-06-23 11:16:51.447365+00
dbc9302d-ab19-46ab-bdaa-a62f8f9b9ce0	1d6bff6c-781b-4679-ac95-648f9ca208f9	2.56 جم من الميثانول CH3OH أذيبت في الماء، وأكمل حجم المحلول إلى 100 سم3. كثافة المحلول = 0.90 جم/سم3. كم تكون النسبة المئوية (بالكتلة) للميثانول في المحلول؟ (الكتلة الجزيئية لـ CH3OH = 32)	calculation	\N	\N	\N	المحاليل - التركيز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	47	2026-06-23 11:16:51.447365+00
9d2f1200-eeb2-413b-a815-aa5b19b6c019	1d6bff6c-781b-4679-ac95-648f9ca208f9	كيف تحضر 750 سم3 من محلول H2SO4 تركيزه 0.50 م من حمض الكبريتيك المخفف في المعمل المدرسي تركيزه 2.50 م؟	mcq	["أ- بمزج 250.0 سم3 من المحلول المخفف مع 500.0 سم3 من الماء.", "ب- بمزج 150.0 سم3 من المحلول المخفف مع 600.0 سم3 من الماء.", "ت- بمزج 600.0 سم3 من المحلول المخفف مع 150.0 سم3 من الماء.", "ث- بمزج 375.0 سم3 من المحلول المخفف مع 375.0 سم3 من الماء."]	\N	\N	المحاليل - التخفيف	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	48	2026-06-23 11:16:51.447365+00
\.


--
-- Data for Name: exam_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_records (exam_id, curriculum_doc_id, title, book_title, subject, grade, country, track, year, exam_type, organization, owner_id, visibility, question_count, extraction_status, extraction_error, extracted_at, ocr_quality_score, extraction_attempts, failure_reason, ocr_diagnostics, created_at, updated_at) FROM stdin;
1d6bff6c-781b-4679-ac95-648f9ca208f9	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022.pdf	\N	chemistry	grade12	sudan		\N	final	\N	JlLBDDgQpkRtgJ3efZ8Lp7yhijr2	private	48	done	\N	2026-06-23 11:16:51.454+00	\N	\N	\N	\N	2026-06-23 11:16:51.419231+00	2026-06-23 11:16:51.456401+00
4fa330de-ddcd-47dc-9dd2-9c6b11fed943	4fa330de-ddcd-47dc-9dd2-9c6b11fed943	إمتحان الأحياء 2024.pdf	\N	biology	grade12	sudan		\N	final	\N	JlLBDDgQpkRtgJ3efZ8Lp7yhijr2	private	0	pending	Daily Gemini quota exhausted — will retry on next server restart	\N	\N	\N	\N	\N	2026-06-23 11:16:51.4291+00	2026-06-23 11:42:27.137569+00
fb270347-276f-4b14-bdb6-01d23076a627	fb270347-276f-4b14-bdb6-01d23076a627	إمتحان الأحياء 2022 (1).pdf	\N	biology	grade12	sudan		\N	final	\N	JlLBDDgQpkRtgJ3efZ8Lp7yhijr2	private	0	pending	Daily Gemini quota exhausted — will retry on next server restart	\N	\N	\N	\N	\N	2026-06-23 11:16:51.425123+00	2026-06-23 12:27:25.346078+00
\.


--
-- Data for Name: pdf_upload_hashes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pdf_upload_hashes (sha256, doc_id, owner_id, uploaded_at) FROM stdin;
\.


--
-- Data for Name: rate_limit_buckets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rate_limit_buckets (id, tokens, last_refill_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (uid, role, granted_by, created_at) FROM stdin;
\.


--
-- Data for Name: weakness_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.weakness_snapshots (id, student_id, country, grade, subject, topic_scores, total_exams, last_updated) FROM stdin;
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, true);


--
-- Name: db_backup_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.db_backup_log_id_seq', 1, true);


--
-- Name: weakness_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.weakness_snapshots_id_seq', 1, false);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: db_backup_log db_backup_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_backup_log
    ADD CONSTRAINT db_backup_log_pkey PRIMARY KEY (id);


--
-- Name: exam_answers exam_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_answers
    ADD CONSTRAINT exam_answers_pkey PRIMARY KEY (id);


--
-- Name: exam_attempts exam_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_attempts
    ADD CONSTRAINT exam_attempts_pkey PRIMARY KEY (id);


--
-- Name: exam_questions exam_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_questions
    ADD CONSTRAINT exam_questions_pkey PRIMARY KEY (id);


--
-- Name: exam_records exam_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_records
    ADD CONSTRAINT exam_records_pkey PRIMARY KEY (exam_id);


--
-- Name: pdf_upload_hashes pdf_upload_hashes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pdf_upload_hashes
    ADD CONSTRAINT pdf_upload_hashes_pkey PRIMARY KEY (sha256);


--
-- Name: rate_limit_buckets rate_limit_buckets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rate_limit_buckets
    ADD CONSTRAINT rate_limit_buckets_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (uid, role);


--
-- Name: weakness_snapshots weakness_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weakness_snapshots
    ADD CONSTRAINT weakness_snapshots_pkey PRIMARY KEY (id);


--
-- Name: weakness_snapshots weakness_snapshots_student_id_country_grade_subject_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weakness_snapshots
    ADD CONSTRAINT weakness_snapshots_student_id_country_grade_subject_key UNIQUE (student_id, country, grade, subject);


--
-- Name: exam_answers_attempt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_answers_attempt_idx ON public.exam_answers USING btree (attempt_id);


--
-- Name: exam_answers_question_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_answers_question_idx ON public.exam_answers USING btree (question_id);


--
-- Name: exam_attempts_exam_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_attempts_exam_idx ON public.exam_attempts USING btree (exam_id);


--
-- Name: exam_attempts_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_attempts_status_idx ON public.exam_attempts USING btree (student_id, status);


--
-- Name: exam_attempts_student_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_attempts_student_idx ON public.exam_attempts USING btree (student_id);


--
-- Name: exam_questions_exam_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_questions_exam_idx ON public.exam_questions USING btree (exam_id);


--
-- Name: exam_questions_search_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_questions_search_idx ON public.exam_questions USING btree (country, grade, subject, question_order);


--
-- Name: exam_questions_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_questions_type_idx ON public.exam_questions USING btree (exam_id, question_type);


--
-- Name: exam_records_curriculum_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_records_curriculum_idx ON public.exam_records USING btree (curriculum_doc_id);


--
-- Name: exam_records_owner_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_records_owner_idx ON public.exam_records USING btree (owner_id);


--
-- Name: exam_records_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_records_status_idx ON public.exam_records USING btree (extraction_status);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_action ON public.audit_log USING btree (action);


--
-- Name: idx_audit_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_created_at ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_audit_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_uid ON public.audit_log USING btree (uid);


--
-- Name: idx_puh_owner; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_puh_owner ON public.pdf_upload_hashes USING btree (owner_id);


--
-- Name: idx_rlb_updated; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_rlb_updated ON public.rate_limit_buckets USING btree (updated_at);


--
-- Name: idx_user_roles_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_roles_uid ON public.user_roles USING btree (uid);


--
-- Name: weakness_snapshots_student_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX weakness_snapshots_student_idx ON public.weakness_snapshots USING btree (student_id);


--
-- Name: exam_answers exam_answers_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_answers
    ADD CONSTRAINT exam_answers_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES public.exam_attempts(id) ON DELETE CASCADE;


--
-- Name: exam_answers exam_answers_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_answers
    ADD CONSTRAINT exam_answers_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.exam_questions(id);


--
-- Name: exam_attempts exam_attempts_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_attempts
    ADD CONSTRAINT exam_attempts_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exam_records(exam_id) ON DELETE CASCADE;


--
-- Name: exam_questions exam_questions_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_questions
    ADD CONSTRAINT exam_questions_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exam_records(exam_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict yTQVrJp7XzO2oSRnh4DXN4y0ePs425p1f0ebp56LQoJS10apkZ9RxgzZIARpZvq

