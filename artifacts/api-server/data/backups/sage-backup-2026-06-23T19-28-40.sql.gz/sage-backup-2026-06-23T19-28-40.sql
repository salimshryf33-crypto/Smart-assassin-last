--
-- PostgreSQL database dump
--

\restrict Ng8haDwfsRowZi7r5sZtuxcyF9EeVC0Ka4vfV2Tcjas31wYeDLqAqTEVBD1NidB

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    uid text,
    action text NOT NULL,
    resource_type text,
    resource_id text,
    metadata jsonb,
    ip_address text,
    request_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: db_backup_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.db_backup_log (
    id integer NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    status text DEFAULT 'running'::text NOT NULL,
    file_path text,
    file_size_kb integer,
    error_message text,
    verified boolean DEFAULT false NOT NULL,
    backup_data bytea,
    CONSTRAINT db_backup_log_status_check CHECK ((status = ANY (ARRAY['running'::text, 'success'::text, 'failed'::text])))
);


ALTER TABLE public.db_backup_log OWNER TO postgres;

--
-- Name: db_backup_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.db_backup_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.db_backup_log_id_seq OWNER TO postgres;

--
-- Name: db_backup_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.db_backup_log_id_seq OWNED BY public.db_backup_log.id;


--
-- Name: exam_answers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_answers (
    id text NOT NULL,
    attempt_id text NOT NULL,
    question_id text NOT NULL,
    student_answer text,
    is_correct boolean,
    grading_method text DEFAULT 'pending'::text,
    ai_feedback text,
    answered_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exam_answers OWNER TO postgres;

--
-- Name: exam_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_attempts (
    id text NOT NULL,
    exam_id text NOT NULL,
    student_id text NOT NULL,
    status text DEFAULT 'in_progress'::text NOT NULL,
    total_questions integer DEFAULT 0,
    correct_count integer DEFAULT 0,
    score_pct numeric(5,2),
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.exam_attempts OWNER TO postgres;

--
-- Name: exam_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_questions (
    id text NOT NULL,
    exam_id text NOT NULL,
    question text NOT NULL,
    question_type text DEFAULT 'mcq'::text NOT NULL,
    options jsonb,
    correct_answer text,
    explanation text,
    topic text,
    chapter text,
    subject text NOT NULL,
    grade text NOT NULL,
    country text NOT NULL,
    year text,
    exam_type text,
    difficulty text,
    organization text,
    source_exam_id text NOT NULL,
    source_exam_title text NOT NULL,
    question_order integer,
    extracted_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.exam_questions OWNER TO postgres;

--
-- Name: exam_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_records (
    exam_id text NOT NULL,
    curriculum_doc_id text NOT NULL,
    title text NOT NULL,
    book_title text,
    subject text NOT NULL,
    grade text NOT NULL,
    country text NOT NULL,
    track text,
    year text,
    exam_type text DEFAULT 'final'::text NOT NULL,
    organization text,
    owner_id text,
    visibility text DEFAULT 'private'::text NOT NULL,
    question_count integer DEFAULT 0,
    extraction_status text DEFAULT 'pending'::text NOT NULL,
    extraction_error text,
    extracted_at timestamp with time zone,
    ocr_quality_score integer,
    extraction_attempts integer,
    failure_reason text,
    ocr_diagnostics jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exam_records OWNER TO postgres;

--
-- Name: pdf_upload_hashes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pdf_upload_hashes (
    sha256 text NOT NULL,
    doc_id text NOT NULL,
    owner_id text,
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pdf_upload_hashes OWNER TO postgres;

--
-- Name: rate_limit_buckets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rate_limit_buckets (
    id text NOT NULL,
    tokens real DEFAULT 0 NOT NULL,
    last_refill_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rate_limit_buckets OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    uid text NOT NULL,
    role text NOT NULL,
    granted_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT user_roles_role_check CHECK ((role = ANY (ARRAY['student'::text, 'teacher'::text, 'moderator'::text, 'admin'::text, 'super_admin'::text])))
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: weakness_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.weakness_snapshots (
    id integer NOT NULL,
    student_id text NOT NULL,
    country text NOT NULL,
    grade text NOT NULL,
    subject text NOT NULL,
    topic_scores jsonb DEFAULT '{}'::jsonb NOT NULL,
    total_exams integer DEFAULT 0,
    last_updated timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.weakness_snapshots OWNER TO postgres;

--
-- Name: weakness_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.weakness_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.weakness_snapshots_id_seq OWNER TO postgres;

--
-- Name: weakness_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.weakness_snapshots_id_seq OWNED BY public.weakness_snapshots.id;


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: db_backup_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_backup_log ALTER COLUMN id SET DEFAULT nextval('public.db_backup_log_id_seq'::regclass);


--
-- Name: weakness_snapshots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weakness_snapshots ALTER COLUMN id SET DEFAULT nextval('public.weakness_snapshots_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, uid, action, resource_type, resource_id, metadata, ip_address, request_id, created_at) FROM stdin;
1	JlLBDDgQpkRtgJ3efZ8Lp7yhijr2	backup_run	\N	\N	\N	102.45.76.48	060ce6a4-2b84-4b93-b02f-b4dea1ba79e2	2026-06-23 12:54:52.568671+00
2	JlLBDDgQpkRtgJ3efZ8Lp7yhijr2	backup_run	\N	\N	\N	196.128.179.50	005cbb06-90d7-4cd2-8e0c-d4dfbd1872c0	2026-06-23 19:28:40.389703+00
\.


--
-- Data for Name: db_backup_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.db_backup_log (id, started_at, finished_at, status, file_path, file_size_kb, error_message, verified, backup_data) FROM stdin;
1	2026-06-23 12:54:52.568881+00	2026-06-23 12:54:53.496069+00	success	/home/runner/workspace/artifacts/api-server/data/backups/sage-backup-2026-06-23T12-54-52.sql.gz	8	\N	t	\\x1f8b0800000000000003d45b5b73db46967e967f052a2f96ca6c1a68dce5ca56c9b4524a4696125bce2499ccb21a4043624c91342fb1e5ddad1a5f646bb5fbb2b5fb3e95f23a52e45b1c2771398ffb2ba8d7fd257b4e3700022448500ebd725c9644008deed3a7bf73fbba49c81942944f9b9dee669b5ffd6c5509589779acc395a0b7dd826767ce7cdde69d6ebbe677959d8dcf3e6f7fd2b2bfb8bd4e9b57af34b68c4b5fac193b2affb46350b3a5852af75aa6b5fa59f393ab9aca5ad7bf72afdcdabcfdd5c74b575a5f7d7be30c0e7509bae58112b69bdb83b1bee5ed4eadd95034abaca9a956de8ed2daaca224434dce5c5dde503a5dd6e5dbbcd1ad766bdbbcd9eb2a1f2aea05f1a8def4af8fdead05755ead35aadd366b7498df85feaa1ddec17e471bfbf51a76cd1b7e33a83536e1c1d96b1b1f39672fc4633702d60eaa7eb31136dbdbd0a28a5a6a6c76a065b381ad56972b1b28bf0fd3ac3737cb1dde15cd6b9bf3673b9cb5fdad6a8b75b7ce9694b3f013b27a872f44636f71903fec35a48c1e48c0b15fd14636b9b55d6fb6f029dc864ebb206b466e90a8ba0d73639be2cd9bacdd00e1649376f326ccdbefb56bdd1d94360c2f488d063c64bd3ae8937975de69319fe3b4cfe63dad32df87ee618cee563380665b9cb52ee012e3faadb16dbea8b05e50eb5661ea17948d9d16dcd858bab8ba7c41b90af3db668b4aabe7d56bfe0565fd6683b7e152a2b0235057b9b2bcb4b12cdf881a9693fe94f9330afcab054a0d66bec9dbcadafa86b2766d75b5241ef4e04997dfeaca2bb9d2e2c6503b18acd96bfbbcda05f1526f24f733fdc054194256f9a6d36c78f25ead55654100ed3b99d76ff4c066b26ffb6d0e700daaacab20d6004080ea9bb5ee96b8546e371b5cb9b4fcd1d2b5d50da5d1bc39bf90c87a065071e6ccd2eac6f29571fa58fff31a3e5c4f74386e25402658fa1bf1825c5dfeecdaf25ae5646b12bf342246d4b998eed2d5786dc4e5d58da52b1bca9f3fde58513471e3e335e8edf2f2da8672f1cbe8d6daba72f9e3b5cf9756af2d27d74b5f0cae2b4b959565451b28a34890dfad16d1c12590703afd9c402aec74a441b916e0e4d212065ed563fef55e6b866694e9b3c89400a7edb783ad7c3fac356a9dadc91d2423757bd28c921ecfb67b0df45b67171773cc37ac811f42179a323371af53bbcdabd7bd784af2096fb79bedd827a6de80c8520b6b186d9acd3a678d6470e16d87868c1427dc80b7d3e54cdeaeacaf5dddb8b2f431c039a3ddaa9c5455387405e05bf993323f1fcdf4436569ed4b657ee9ca95a52fff32345388099d9ef0b0831b2183b905d1f55f171616c63a86ec0a17594156e277e020f2063835279127cc4c543413673156bab4c3c834ca711afc16dbae428a731372a619f98c74970397916393ac0b39592b897d434f455cc49426ff71a7db0b30799103a56cb40626d46cb73924a19195cafb9b6d86c9599c85647d478b3782944549f16ad590f300d597ce10c478b30dce198d15e14b3696aa9bed92457d4e5c33d172f28a8c7b9ae3b221f16cb59b285a27df6d779b900f5763287492c013f7a04609935c7058f85ea33bae51075a410c005c347adbe0c8fd79b344176613bafce676abce0b7a2858ff58fd53012051c92c1130d0f35b4220ee60a23d2709f40007dbfe8dfcf597754b279d46c76b3d62f8fc56abce1a2c193f4650abe6a773eb2dd6ea66deebf4bc6fd05be40c8f3e83e73d10406befe43dda81722d2315686ba866086a6158f3a13eda49dd6cb63759a3767b58fea8ba986477a916dd5ab79e2b70a2fd663b80d967b39d5b50e5fa2782ff64280f70341596613941aa992239ea32c2f104e54165dbc6a5e86d5783a63fa6d158ad4280b99ed2f93bc113ae4d3a004dc4d7c0a4209966f53146958fb4262a385b887e5bebd4bc5abd160135152fdbb56fa144cdef3fc1da44771ca14e102b79b1211b92477c50f2b2c8d5330a9902cdd18cfd366095e1fcaa223ae4da050e9238e74c03ccb27b1053a05cef6455091d0735b6d900b0d6fcacfb7aebda3ee22b5ac1acb9818cc514596c2b08abbd56bdc982ea16836a6d56663bd26f64bb9d2d464d2bcf30c6db6b0e9265d7b3d5dba8c845ca6bc3d255ebb56da8e1bd9e7f9dcf2c811bed786208ef36af73f0ce00c5fac02c87dad459a70ba88022b9fef669d1fb07f61c4d15ad5aaf03686a432931abd51a7418ad522f7f99b0c99830d240b578e9fce1f7ea3ac54b0ce413bf872809215596908852ff01ffd0e50c5e6a0f6e6c3721ed60dd66ea160bb66b8d3487d18251d33727f216291d16addf4dceae379080ee3458abb3d59c99d58d765c4c914daa9126640163338709d986487d65608b42d020bafed3bf8092e5bdbc8a0b43c2d86a4b7886c83467669739ba3cf9babe0b466aec28a7464b8d9568761a9b09413559ce344b35da3287aa1a6c61c0b348de0864279152a26e7d6d75945457648bcafaeab5cb6b68c4b89595e0180cec5b569f3f3b86ab077b6af34d1f8ca3b330919a9fb5f8d9ce4f32853c0671d234726c74c673c919e124131a8bb8fc595d426a3e84ea61d21ea472696963694a0fb2fe690ea8e66b4109237c29da5d2c65f7124be92dc452b273584aed179652db84a554a05f503ebab27e19820a144a17ce68739fd4572f5ebab4f959ebfa95eee6273a0fbf72565bf6ce56ed9b369d8b56badd6bcc7dbd16fdd7545a36ccb26d950d674eb5549f5bcc20d4730c6278ae4e3c9586c43302ce348fd92ea77354a516512d427545a38ba6b168d2b2693996ad9d53d5335f97c7e976fce6d45bea7768670a153320f14ae9bda452c43d96069b40a5ccde4f29bbdf534ab6794ae93d9c61658fd184e3a02650b9d12ecddcf9ade6363f8f57bc7dfe66b37d5dec969f07596b2120a2739eb56a04b21918f53c0e745e0eda398fc210794106a36d6894980681d13a37eae5cddbd15286f06b82fec7f2fc6fa9fe2cc92fc09db0f9a534775f1a62ea4b2982be3444ca97d29c7b294db567955f34cd3c72fc77cd3361c6713e119b544a257303880d11d6a52c355d1a90d059b8a6f9e313cd359f07fe3d934d91c099d9c6f74b5926b71473b4a52166b69426644b32192dc5f46b29ce5b25047829ce7d4b82df2a0d68ad528a2d2d65a8abd210375a1a65424b43bc6729c30e65156deb34e4a11512dd741c629821259eed06c4b53ddff47d83f13098d302cb0b43cb27b6a379c4b06c9730df35896538a1eb33aac29fb9fec1f1fde3ddfe1bf8bbdf7fd9ff41397e78bcafe0ddfe9be35d78b60ff7c4e511dc87aba3e35de5f8cef1fef1c3fe81025777fa07d0f2be029d3c83e67bf0b10cffe620a2b563f50e9cf8f070780f17bed6017dce09f56a74aed30b98f0fc82188cfdff54d3790cbd1ff59f41ff0f84d8c7f740d45d18eca0ff9d028e89ce65bda1b6a8598ba656360c5bb74c8c0b9ea7739dfa215199151023085de2780127b665eab6ebdad465d609747b0f74743fd22108b2872a3dfe0f54f42e8808e2dd4775deefffa4f4ff3ee7b33a80472066486779dd9c8afa6881fad420b44d9bdac4b40d460cee82fa743520dcb63547d53c4fa36c4a611e01420e012b30eb37c77b200ee01120d7ffeffe93fe4b01424560e905dc9e57faafa039365e88f11a43736822df23c0ff5d81ee7f04b5be14405e1c83d7a4ffc22e4f6129f482a5703c57d3558f124a21533298e913d7b239618cb966a00581cff4a9910c00ec1f2ac777511e80df8371aa3feaff86a68d1f5ea2c8086cd4dd215cee45be63589be3bcc57bad7da340fbae498320545562aa1ef868cf821495fb1afa119f5a811338a13dadf6419057a8fd69d09e2818ee1c09972e1afc84fe26f1e6d013801f8c0a9f97f3fdce7bad7db340fba1ce743380e0e85074439a671127648cf8ba1e6886ab05aae64e29cc1bc4ae02f0c5e17fc5dfc7ff861e69ac090ca9eb103ebc82e93cefbf401f96b1a13b298d461e7eac314c7ced1496c02a580223545dd3652ed1596012430f03e2f8e07e42db8116b00696a59ed4fd88d401558e013483411951f700e7a0214439242afd27f9e805ec8b5ce619acc893b10a17d3ff553a337ce9317c7c8289cbf18353d0b65da06ddfb1029b519d380187b4457702f0f31c3cbeef793ee596a6dbc64cb53d5070a25c6119d0ec2eacc30b45a81d7c0c2a4cc196d0e809faa6a7227979252cea058e7208c3bde87f2f0deb50287bd0664fda577453be061d2e2830c83378f957f94cd898100f9fdf53c41a8b27bfc0dddf40e045a5b2a22bf39515baa059cafffeed3f95cafafacad8c52f16fd1450e014655faa1942b60a966686e0f62ccf001498e00575cf0f35cbd37830addbc3f11fc0c847fda732579d2260a7a1d03f1ac1cc2928cc2d8ad2a169d9beed116e3a2a3154c854195743427dc7a19a6ad89e36659406510eb07ada8bf1f85c78e683e33bf2c623800d8014002e5185f77e06048ba4682f8ad1fbf0e9082b81f1e5d398974ea392520b944b9963b981c789abba309066a99002792a09996104beab52cf764ea05c10e629ce7b5069a61c0060f52832fd95b5753d65ff8344542d6baa22ab27e5bc028e6d571f8a074768f318dcef1fffaba26b655389864425e40e262fc1e5c16b7f8f1c55a65aeb3fc5258a9da67cf91582009deafde3bf49713f542cbdac82571b938c0dcd245a7ba190d358f9a2225a67d09b69db44e5a64e0c17ab40a8ff886f3b8ea55b866b587c4a698e22571c99cc6bf87d37d6e4484c92a9edf3240b1824c3bb18c9e2b27b5cb95738c269e8baa8e2764c035c9607e545c86db43224625d463c95594ca7cc53e9d43e3f2a34e0cf4b8ca430e17c3426cf87d2abd3d04f5119ec3b864e39f588adfa1013994b09335c4e7483dadc093ccfb0cd691909187e37cebcd3d951649e07116106e6f90adc46268642fa21928e15e59cb272b1adfcb3b2a257a68ba330d0afe898a6c4df360f6abded99eab8a8d85555ae39966612cda72e605085c4d30b18a134b42c53035f40bd13916618e2e4e497949272117e2ae82d91ab016f7b07e3683ab71b71b4156b4553d7cb4a7c53ea31d5b732bf24d88a219f0feb765ffc60c68bfc133a92a8ba10ab22ab3c911aee82a240638fb022db87ae001d603d2f1450a8e8ea1174f302f9d4fe8bb29264d5a3721f0a8c7c1f47848c8863abc1f41a9d101f5bac1dcc141d45c5b8e3ea9e66b290e83a2403864a1de25a7e482cdf64509f80f7b24e4257ffbfa0e3e242dce3444860d171171532252844fc46c43d784b485cfc6340a2881c502d8b6a6160131bb36d23f04228595ca8565cc706c7617aae393d373953486450504114601705f68d177bbf7f712b7f8cc52de2224c8b3b1ab31cc24c8e556800f6ee188c849e6fb99e17ea9e356dde9f18d4808cc13d13642e450ebc8f75393e3f14828bac64a4859c8b74f0a0fb67b20ec372ec399a29ac22bcf81456839aeafffc8866fdbd546f6a190bc990bdfeaffd67856cd3bb58df7710ef8b78069bea01f30d8f30ea6ac4a0d4240eb24d3ad5d590591aeea14dbbc2b8b031c776186d90ede28de8227fc1e7954f3faf200bb43b98c548abb419262698f05660fe3061d9817405df4d1e74bac51b9a07faa4a99691b3cece4c17b188fbf06ce66a816911cb61b088966f40e1e050f0c69a1b86bea11bde945b7559ee03c418c13fc81a71e0f0f421dadc63d0f94ba9b194bd3c062c1cc0a508ae6fe2441bca5e5842a4ef046db742a15ec6df22e94e93b483b6fa8a0d49f65826e5fdb2375ac4a4386a08a934b850a6d90e81fb0ed4d3d4261a5543d3b054230cc229972a67ff6d511424e79435a1e0fffa07f8609c83eb8b6d821ba582ca8a2df48dd8cf482abf5f2074a105ff509edbf66fccfde503ec03b72ac4ce8858684885f0c3706a2432273014b143826626022772c0e50f4aca072851c4b8bc751f621a035846520d788297083551eb4b22e6625bbc06d34e117929d6277923d5feaf73b398b128fa1e89b10e70c67b8243175d9e16248b281eea52d387ba8f787e680324c18530668644b3354b0fa90d8369534af30b6668c9d1068cb229e2e6ae08b2bba345769c863d96849bdc2a10899ae09e453a38e6e9227a975f708d01d6955ea54e01e7695ef140a4fcf7e263060983f41db45b6395ba383f8054005226f16eebebfecbb1c478ae18a7121668119f64a881636244704d0aa9b9eac0a7c0f589c91dee5a2c60dc9a922f91613cda95911b3d07fd9ff11ea464b8eba3c0d50b68f05051cbaa26542a985168f15c70e7997345682032d5ce2a5e9c9e99bf2c0ab65d61dfa6cceede4824c87d70e4b560145d4d53bad9f77153170790407c0812be2e6348fa11a3db3dd46954260a0efec1d0c9a867e2bc94a8181f21279fd33f06c10341379cd31171f790244ad39b59e6f847b1cf94c71a677a1d736e28b3f470f1501ca739099139ebc281165175a6ee68960358d34498e31c0a4203b2ccd0f1346a7343d5199d521a59647d27b7ea859f4838bbe3fd147319bb934548fecb2a16fbbb7a74362b7f9f41d47bc28ee30c516c03605679a4a40638925038844041d5b13d0f1885848300c7b40791645f6cf2f413ce5f18896646fb17e7c5ee45395b9664c3fa22782a5a59d72190d3954a5d46768ade0b1948ba0ebf2bebb42c51889390284c6d329c480187b1ff8e851b8bcb939eff7b07c1adf0f00e55996a239d1ec21810dba0d2d1558d98b66a07be1afaaa36a50fd4acb16bffa7cb8d750317151f89836d11c130012f1ff1abf08e3cfbb6078d5f474b73bc5f1ec34a47be28f11c6980981f718a891e0a42e0afb3724ec2041ee8f281786e005cb0ff787b20172352b4511c4c3a5e94d862c4adf47f2051baf91376733a5eaa88ceb435c87d701f5337c137198c07c4d51d9f504aa11c0e5918b8d3d64d39c9f89050dfc72d7ecc9ebf55e254f679ffb5c8998ed0d744079264dcdb955bd0584dc9f446d4685177f2b55404135a79210f6444a79ae2434dc3679ac6ef4f3f8b80f156fb4233cf748a48c850a3d4f04c87309b9ac4f0bc8078211e030803060f98ed39d31ed17b0313bf8399c5c33881b80bf9e061f45148f50a6c749a6af4ad42f5cc7557c4f1e91ad71ceee924f46c034f9a84c475e1131eecf24d46a96b4c7fc0ee659cfedf13e93104be3f90a68ab8327015d4618e453c1afae02e02486a3435243e378d50b73c4aed69a9eed1a466886a4cdca8204afac94114e94e33290fa407eb3a99673716301d38177db8baaeff239577452000971e5f9fc3930a143fa669d10790aedc192fc7d8826820a9f05e2773f9ef20232822cb2c3f607ee0db446526ee61e90ccaddd02541a031aef99ea959d39eaf936eb6ff1bc25e92c9f7a3382f9439121216132d679778d034ee6a1ebf7a8127e3d22fa40130ee9549e7216425b68fc9ac54ddc328f93bed93117a116b66e92a352cc7232e752d18c83288e7436b5f0b0d0ac585c5c269d7ecd1808e781d9de01aa4ccaf24e79b2d0d01d6987a3d947117798da7434d261ff37a7fd55ec40c059c078e699a84730dbf4163e9c46596707ddc375caa79eed427df93403a16ecb9da9ff4fda3f758b345d40c654cc72fd0101802d214dfd008b320061ba60fe138700dee4db9b1368d667341fb07d56c11f360d88ea932aa91d0d210a9964b3c957362a9168867e9ae1f4c7944411e0a00bfbd2fb9dda4224a0ab3c1618391e36bf22b493257874e7e866622a17c224f130d769447eabcdcb37051621f6d78c95ea33e919f282bd1aea5785944f1ddb8aa8bbffd27673038b21a9f827f90da8ed1e3f3888f93edb9c11e0dbc7c0f69bf381cc55f04bad8a613bf2538b2a7966cd228249e1c3c17f2a6048c7780a6e657670cb42266811b81a19ae012ed104f681b814dfeafbc6be98de208c267f81573b4a519677aa67b1e481c8c770107c7c02e448092aca6777a30c2b137364e30a7106325e24c947388a2580121852807cef913eb6b7e49ba7b5eddf3ecc5bbf88104c26b66abbfaaa9e9a9aeaeaecf37311d371c42e439d0a7efa58fded1926c53e66bbcb2668f791a2bd967c27ee7baff255d93ebbb9ff8e1b3e42bdc45f7f31d483e587aecb298725b0dcea25fb6273502400783c6d005910109a203059e6d108bbe571c0f464835be3dc37e19a73ff7d8529e7e344036cd65fbd2d5ff6613643af9b172956ca7fb639816db52312102be497c6244c8f769cce8da868742cfc05e1839c48c70642aee26f21ca7546f955b68c9b98a2e6df1524eee067be397ac948405eabc647c9fa723a91af37cdf5bb5822b5dc0c5c13ecbb5fd94e6d2d8b4f42e5d77c7431e24f725befa68375bd0e4d86e6d5ba6c823280a42d3337cdfa62b6736bd048458f48de760824276c646f544787a1344b5b5b9c35fe79b0afa4f87155b4f76e130c45e4497b15ec0b6c620347c8f06a80446300228b0bd40b58abdc68a2fcf8015dbb23836f03d6443dfb0083b94ed2062049113182e1a12ecfb5e0822d53a9ad627fbd45b13b6e5574c1c60d773803174205d3479d03102178686e3d11f89ebc0c851dcae9537a6346b916d5a5e8a53904b6c2e1637e1157628e2729b78ab1d2cb848fbf7170d985f19e9f66976fc6b61fc2a8d4ff8063b9fd0c7f161d21ff96a762faffe6049b7b9c5f974e73e4b006578b2bdfcb9a5f9da761ee949f102e2720c731cb7bc2db733f46160fb2cf9091134e86a0518343a4474d91cd85664fa013287ea3583f14d7d7ef8c3f81f16e41d244f42d2e9e30f5e7dc5ecf3b63955c62e7a7b1cd66a6d8662bac8c321325c93e56b08a2010d3597816110f9c401c835d5b30ae2e952ae713e4fbc6620a9639d4c2bb5e55e6818605b8ecdf653111d08b921351035956399d87703c70c54732fb5fec34dd778eaefd8acd3963008fda1475cfaca7271840c18b1722c9b1a2b706dcfb26c1201a0f8c43578ce09b64fdbc215878495c0b20367f44d0431b6a87df81e9b83c300120ffb8a8111eb89572c0edb1752103c9b70fd6adc39e839af5f2b5707f2b47f724a303eaf9cfc77564a13972d023329f16005387c887429285c7b513317fcb860ed93ece29a6a9de230421d46fab6630794632b8f6bce271fb2bad658cb8b9a6dcd3774a4dae7b7ed19cfb2a42bcf14cc71f849eb0a130f7ddbb44223c080ae309d001bd43fe88bccb1223a06f68744b11dc9e9f113b9b6300d70922f27675ca84b1c884e311fd717ca0a89f89341cfb433b5ad69fdd08a80659a062174be81c0c646e001c42aa0a9776167a8dc5e28cb3c25c7605c5457fa75d5e2f555724120620d0dcafd09f6783e89550b3dcf03d837f42e3e956ee5bb43e134333b04f5775c08948f60c523d0c8222eef1fff66c475466fc7afd97129b950ade8c2d2b8ec3c0732abbf412dcf4befc707827830b178a74dfc9f82f8ba8bebc5d701cac4bf12c4db2e9a507cdd37b8f82f5b1f9737bc2de3d3e3785cda92172d8d41ab48758ed2163463d4c9ba6d96a873742d69ba99d3e234f4f9e4bc3615ed3ee5169f2995872e70d1e8058619bdcc25a3971862e4d69f7a99fb45afe27bd10b1c2f7a91da456cc7ac0b7c15856ec14a55add3f11c464bd2e4af92c336768c4e487e982b869b1b845d5fe99208261d8fb33f959701dfb2796fe46a210e3441dce22ca0a178488c301c860674431a8586210d40870e062022a14f173f4a1751f3fc5cb016fdfb829fae4aac05536be1079beb9bf78f6e2bf35cc25b74ae431d6757bb426fc2c603eab09bf411258fd7829d6dc69af0dff72fb4ef1eacaf6b5b84113e6c6ef056e65adc059a350467bd812593d659d5f22b6c0aad0b96bb00e8e4e7f8bc28135bae6943d7b05c27a2f13c80344ec3f40b20b46cd37568bce69e53baa8e47ffc8455ee7dda1c983ffd3645c0b28b566526bd60a1051b3aa6eb35cfc0cd2449ef390d573024c5e448ba96cebff96c29f01da9f6936e21277a4fd455cc44fc55c12988f402cd90da745aaf430d55cf7b6217797a78037ff6b32ed0efd437e3af87d8c246f39e50aba8688a3dcab3576ff22ace5ecd22518c2e32c0e812d74bad868a0cd9fdae223b44bfbbd25dbaa58dee0f86d4768cb8769b34736fe81a6011c50e69a6de983db24a4a8d7a74ea842cd383584f92c171722aeb12d09cce22b7fde821d94d71e6ec5153e26289d9753a1d91974a1e5abbd15bfe6cb17757bbd6bdcb9cbd857545be33b3c02e8d5085bf0ca15507896741fc30130dc401aa14280150c49ff227489f66a8413242bd0a2204351d725a04f9e3ecb4c886a8554306a1a647ba8e133fcc4e8764805a0d440032fe64995952a21c05957e3313754aa354e9540d45562c8ed94a7a55c449e55fcd44b3f23055aad58069753a218612680567a1472ebe0a7f6170197716dca9505e55bc3f67a14e79982ab56ac0b4de1635bdf2e87190048f031e3b0e92d0717092f45601abdd5e5da601157d0adbe3e2c677f120a73b7a9c5a6079b5d3bd3311d720ff46ad5c6a964abaa5dbfde5d52b1a7eb4458836975fdf8c57a0649a2e6051b01262e10bcde1424aec3325bc45a925b0699422a1ad7b0fc932e3ace3f4b1e672d5d09629a95a81a75f983af24cf0a4d05b02b0e9ba45596c116e1ef9a93b462e759b045bc3b519c0cd052b02ae5dfecb1c596d0ab12cfd0cd449c54e66fd02195963c83b10362ca685bf5a74518734e6966f4771fba4197c9ada9b2eee4caa12e4f4ea66a4539e0bcb6295b096b6844aa0a9a4419c5188af3b2adaa23c01669e3d91dfddfcba06607976717ae0049ef05680c2b59d6e7fa901e94e4e047b74888c0ebd15db4e851f3211a39db5d8ada781271326e029af40d51e12266f6b1da7d9d469c013c409002b9692b2e5f2b47a154661a534a5bb2a4b14900a8bc3d67bdb18f11f79aa69962e40ae58384d14c654e6f2f2207e10094baacbd78e27b35780a35dbedeeb2e5f598d1793c28243eb752f777b2c3dddaf0cf0d8c29399aed35de9524b2f2df697163b5d75b3082b85136197221ed930e2baa6ce3259343369ae348977666b06e5b4a9884636421a15d719207957e7d7a9b9476df6f543d8659244ec87b1cc8d187bffe68ac618a371b04db470e7eb51c623cc95fa626783ed7ad328f391b67bebe6e75b9f8edc3b4fae5b9bfddec61aecdc5985bb26b9b10d2d34029149f008392b37373fed0333183dbce7f71edf7f726f79b137baf7ed37e7cfff0f0d819386fe9b0000
2	2026-06-23 19:28:40.389516+00	\N	running	/home/runner/workspace/artifacts/api-server/data/backups/sage-backup-2026-06-23T19-28-40.sql.gz	\N	\N	f	\N
\.


--
-- Data for Name: exam_answers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_answers (id, attempt_id, question_id, student_answer, is_correct, grading_method, ai_feedback, answered_at) FROM stdin;
\.


--
-- Data for Name: exam_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_attempts (id, exam_id, student_id, status, total_questions, correct_count, score_pct, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: exam_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_questions (id, exam_id, question, question_type, options, correct_answer, explanation, topic, chapter, subject, grade, country, year, exam_type, difficulty, organization, source_exam_id, source_exam_title, question_order, extracted_at) FROM stdin;
732fef6f-3588-45f2-b79d-97bc5cc4aefd	1d6bff6c-781b-4679-ac95-648f9ca208f9	المعايرة هي العملية التي يتم فيها تفاعل محلول ....	short_answer	\N	\N	\N	المعايرة	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	1	2026-06-23 11:16:51.447365+00
bb3e32cf-0a6d-4df9-8bde-7653799729a6	1d6bff6c-781b-4679-ac95-648f9ca208f9	الكتلة الموليّة من كل فلز ؟	calculation	\N	\N	\N	الكتلة المولية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	2	2026-06-23 11:16:51.447365+00
0df75727-574a-4e99-830d-e771801bb12a	1d6bff6c-781b-4679-ac95-648f9ca208f9	أربعة عوامل تؤثر في معدل ( سرعة ) التفاعل الكيميائي ، أذكرها :	short_answer	\N	\N	\N	معدل التفاعل الكيميائي	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	3	2026-06-23 11:16:51.447365+00
8b9130b2-22a4-4a5c-967e-aaa95d1ddca3	1d6bff6c-781b-4679-ac95-648f9ca208f9	اكتب قانون معدل ( سرعة ) تغير تركيز البروم في التفاعل .	short_answer	\N	\N	\N	معدل التفاعل الكيميائي	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	4	2026-06-23 11:16:51.447365+00
952ddf00-50b8-4b63-bec1-765c26d8d8f7	1d6bff6c-781b-4679-ac95-648f9ca208f9	احسب معدل ( سرعة ) التفاعل في الفترة الزمنية المذكورة .	calculation	\N	\N	\N	معدل التفاعل الكيميائي	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	5	2026-06-23 11:16:51.447365+00
f3a35d88-824a-41b6-8faa-c33d1491d019	1d6bff6c-781b-4679-ac95-648f9ca208f9	عبر رياضياً عن معدل ( سرعة ) التفاعل باستخدام قانون فعل الكتلة .	short_answer	\N	\N	\N	قانون فعل الكتلة	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	6	2026-06-23 11:16:51.447365+00
4f0959a9-3ad5-43fd-8c7e-f78365491660	1d6bff6c-781b-4679-ac95-648f9ca208f9	اكتب معادلة كيميائية موزونة تمثل التفاعل الذي يحدث .	short_answer	\N	\N	\N	تحضير الإيثاين	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	7	2026-06-23 11:16:51.447365+00
c86d7a23-8ded-438d-aaec-9cbbc2e61374	1d6bff6c-781b-4679-ac95-648f9ca208f9	اكتب معادلة كيميائية تمثل تفاعلاً يقود لتكوين ثلاثي جليسريد مبتدئاً بالجليسرول ( الجلسرين ) وحمض الاستياريك ذي الصيغة : CH3 (CH2)16 – COOH	short_answer	\N	\N	\N	تكوين ثلاثي جليسريد	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	8	2026-06-23 11:16:51.447365+00
005f8bdd-85fa-46b4-aa58-83bcf16b1ed9	1d6bff6c-781b-4679-ac95-648f9ca208f9	الناتج من تفاعل .	short_answer	\N	\N	\N	تفاعلات كيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	9	2026-06-23 11:16:51.447365+00
9f567c7b-e580-400d-ae0f-2c8821047b17	1d6bff6c-781b-4679-ac95-648f9ca208f9	ما هو الاختلاف الأساس بين الشحوم والزيوت ؟	short_answer	\N	\N	\N	الشحوم والزيوت	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	10	2026-06-23 11:16:51.447365+00
2a869dbe-909b-4160-beb0-fa44dc902b78	1d6bff6c-781b-4679-ac95-648f9ca208f9	ما حجم محلول حمض النتريك HNO3 ذي التركيز 0.10 مول / دم3 الذي يحتوي على 31.5 جم من حمض النتريك النقي ؟ ( الكتلة الجزيئية النسبية لـ HNO3 = 63.0 ) .	calculation	\N	\N	\N	التركيز والحجم	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	11	2026-06-23 11:16:51.447365+00
3aca2577-0e53-4999-8718-c7886364946e	1d6bff6c-781b-4679-ac95-648f9ca208f9	تتكون الطاقة الكيميائية المخزونة في المادة من :	short_answer	\N	\N	\N	الطاقة الكيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	12	2026-06-23 11:16:51.447365+00
854ae0b3-bfe7-416e-ba9a-b0a6a32ab029	1d6bff6c-781b-4679-ac95-648f9ca208f9	احسب حرارة	calculation	\N	\N	\N	حرارة التفاعل	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	13	2026-06-23 11:16:51.447365+00
c8432e2b-70ca-4a92-a49e-3427e8dbb475	1d6bff6c-781b-4679-ac95-648f9ca208f9	أكمل المعادلة التالية وسم الناتج : C – H + HBr | H3C	short_answer	\N	\N	\N	تفاعلات عضوية	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	14	2026-06-23 11:16:51.447365+00
00e18615-1c29-410c-9bda-22f6651a252b	1d6bff6c-781b-4679-ac95-648f9ca208f9	الكحولات A , B , C لها نفس الصيغة الجزيئية C6H10O. جزيئات الكحول (A) تحتوي على سلسلة كربونية متفرعة ويمكن أن يتأكسد إلى ألدهيد. اكتب الصيغة البنائية للكحول (A).	short_answer	\N	\N	\N	كيمياء عضوية	\N	chemistry	grade12	sudan	\N	final	hard	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	15	2026-06-23 11:16:51.447365+00
893b15af-33be-4028-96cf-6c5a9cbae06d	1d6bff6c-781b-4679-ac95-648f9ca208f9	الكحولات A , B , C لها نفس الصيغة الجزيئية C6H10O. جزيئات الكحول (B) لها سلسلة كربونية مستقيمة ويمكن أن يتأكسد إلى كيتون. اكتب الصيغة البنائية للكحول (B).	short_answer	\N	\N	\N	كيمياء عضوية	\N	chemistry	grade12	sudan	\N	final	hard	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	16	2026-06-23 11:16:51.447365+00
06621fd7-7e0f-4dbf-8594-a987bda5b953	1d6bff6c-781b-4679-ac95-648f9ca208f9	الكحولات A , B , C لها نفس الصيغة الجزيئية C6H10O. الكحول (C) لا يتأكسد إلى ألدهيد أو كيتون. اكتب الصيغة البنائية للكحول (C).	short_answer	\N	\N	\N	كيمياء عضوية	\N	chemistry	grade12	sudan	\N	final	hard	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	17	2026-06-23 11:16:51.447365+00
56e81a68-a5ea-46d8-984a-fbc69bbf3b68	1d6bff6c-781b-4679-ac95-648f9ca208f9	يمكن تحضير كلوروايثين بإمرار كلوروايثان على نحاس ساخن لدرجة 250° مئوية. اكتب معادلة كيميائية توضح التفاعل الذي يحدث.	short_answer	\N	\N	\N	كيمياء عضوية	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	18	2026-06-23 11:16:51.447365+00
723dac4b-a291-4225-8aec-3230fa61b3e3	1d6bff6c-781b-4679-ac95-648f9ca208f9	يحضر البوليمر بولي كلوروايثين ( PVC ) من الكلوروايثين. اكتب صيغة تمثل جزء من جزيء بولي كلوروايثين.	short_answer	\N	\N	\N	كيمياء البوليمرات	\N	chemistry	grade12	sudan	\N	final	easy	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	19	2026-06-23 11:16:51.447365+00
b7a91d56-68a1-46c4-ba82-4d19ffc434ba	1d6bff6c-781b-4679-ac95-648f9ca208f9	ما هو المفاعل الذي تستخدمه لإجراء تفاعل إضافة مع المركب CH3 – CH2 = CH2 لتحضير المركب C3H7Br ؟	short_answer	\N	\N	\N	كيمياء عضوية	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	20	2026-06-23 11:16:51.447365+00
80f22f4a-a178-4478-8727-120f54604fdf	1d6bff6c-781b-4679-ac95-648f9ca208f9	في التفاعل : HBr + NH3 —> NH4+ + Br-، اختر العبارة الصحيحة.	mcq	["NH3 قاعده لأنه يمكن أن يستقبل بروتوناً.", "HBr حمض لأنه يمكن أن يستقبل بروتوناً.", "NH4+ هو القاعدة المرافقة لـ HBr.", "Br- هو الحمض المرافق لـ HBr."]	NH3 قاعده لأنه يمكن أن يستقبل بروتوناً.	\N	أحماض وقواعد	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	21	2026-06-23 11:16:51.447365+00
2925c00e-bcf7-44a1-aa5f-17163f279ca1	1d6bff6c-781b-4679-ac95-648f9ca208f9	صنف المواد في القائمة التالية إلى إلكتروليتات ولا إلكتروليتات: مصهور CuCl2، محلول السكر في الماء، NaCl، أملاح الفطر.	short_answer	\N	\N	\N	إلكتروليتات	\N	chemistry	grade12	sudan	\N	final	easy	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	22	2026-06-23 11:16:51.447365+00
40d858a1-952f-4081-9d9c-5e8e96adae65	1d6bff6c-781b-4679-ac95-648f9ca208f9	مر تيار مباشر ثابت شدته 0.01 أمبير خلال محلول أحد أملاح الفلز (M) لمدة 5 ساعات فترسب 0.030 جم من الفلز (M) عند المهبط. إذا كانت الشحنة التي يحملها أيون الفلز (M) تساوي +3، كم تكون الكتلة الذرية النسبية للفلز (M) ؟	calculation	\N	\N	\N	كيمياء كهربائية	\N	chemistry	grade12	sudan	\N	final	hard	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	23	2026-06-23 11:16:51.447365+00
5381689c-1178-4ee4-a44b-f8b127e403a2	1d6bff6c-781b-4679-ac95-648f9ca208f9	بناءً على المعايرة التالية: 25.0 سم3 من محلول حمض الهيدروكلوريك تمت معايرتها بـ 20.0 سم3 من محلول كربونات الصوديوم تركيزه 0.15 مول/دم3. معادلة التفاعل: Na2CO3 + 2HCl —> 2NaCl + H2O + CO2. كم يكون تركيز محلول حمض الهيدروكلوريك بالمول/دم3؟	calculation	\N	\N	\N	معايرة	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	24	2026-06-23 11:16:51.447365+00
920a07e7-4f79-4a1b-a301-5707dc0fc015	1d6bff6c-781b-4679-ac95-648f9ca208f9	16.0 سم3 من محلول KMnO4 0.13 م تؤكسد 20.0 سم3 من محلول FeSO4 في وسط حمضي. المعادلة الأيونية للتفاعل: 5Fe2+ + MnO4- + 8H+ —> 5Fe3+ + Mn2+ + 4H2O. احسب تركيز محلول FeSO4 بالمول/دم3.	calculation	\N	\N	\N	معايرة أكسدة-اختزال	\N	chemistry	grade12	sudan	\N	final	hard	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	25	2026-06-23 11:16:51.447365+00
71292eb0-354b-4aed-938c-222a29fafd9a	1d6bff6c-781b-4679-ac95-648f9ca208f9	في التفاعل الكيميائي الذي يتم في عدة خطوات بمعدلات مختلفة، ما هي الخطوة التي تحدد معدل (سرعة) التفاعل؟	short_answer	\N	\N	\N	حركية التفاعل	\N	chemistry	grade12	sudan	\N	final	easy	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	26	2026-06-23 11:16:51.447365+00
f1224b58-a725-4bbd-bf80-4fda24ba7b87	1d6bff6c-781b-4679-ac95-648f9ca208f9	عرف جهد القطب القياسي.	short_answer	\N	\N	\N	كيمياء كهربائية	\N	chemistry	grade12	sudan	\N	final	easy	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	27	2026-06-23 11:16:51.447365+00
31e18eb3-fb74-46bf-9974-5491c5a22949	1d6bff6c-781b-4679-ac95-648f9ca208f9	عرف الكولوم.	short_answer	\N	\N	\N	كيمياء كهربائية	\N	chemistry	grade12	sudan	\N	final	easy	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	28	2026-06-23 11:16:51.447365+00
2eb28a86-b2fc-4ad4-a10f-ce54f36b2273	1d6bff6c-781b-4679-ac95-648f9ca208f9	بناءً على تفاعل الأكسدة – الاختزال التالي: NO3-(aq) + H+(aq) + SO3^2-(aq) —> SO4^2-(aq) + HNO2(aq). اكتب نصف تفاعل الأكسدة.	short_answer	\N	\N	\N	أكسدة واختزال	\N	chemistry	grade12	sudan	\N	final	medium	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	29	2026-06-23 11:16:51.447365+00
6cdacdc7-0a5e-403a-aaf9-dd1ae1cb5164	1d6bff6c-781b-4679-ac95-648f9ca208f9	حدد غرفة كل من نصفي التفاعل: نصف الأكسدة في الغرفة (....) ونصف الاختزال في الغرفة (....)	short_answer	\N	\N	\N	الخلايا الكهروكيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	30	2026-06-23 11:16:51.447365+00
6302468b-9296-4664-bc06-c1f42ee46af4	1d6bff6c-781b-4679-ac95-648f9ca208f9	أي القطبين يكون سالب الشحنة وأيهما موجب الشحنة؟	short_answer	\N	\N	\N	الخلايا الكهروكيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	31	2026-06-23 11:16:51.447365+00
deed8555-ee1d-4d63-9a6c-4adec4921b97	1d6bff6c-781b-4679-ac95-648f9ca208f9	القطب في الغرفة (....) سالب الشحنة.	short_answer	\N	\N	\N	الخلايا الكهروكيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	32	2026-06-23 11:16:51.447365+00
2aa3b12a-6790-4c41-a6b3-45c1e1d94eb8	1d6bff6c-781b-4679-ac95-648f9ca208f9	القطب في الغرفة (....) موجب الشحنة.	short_answer	\N	\N	\N	الخلايا الكهروكيميائية	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	33	2026-06-23 11:16:51.447365+00
47850a21-f61c-4a69-b0ee-606ade639cdd	1d6bff6c-781b-4679-ac95-648f9ca208f9	مستعيناً بالمعادلات الكيميائية اذكر ما تشاهد ثم اكتب المعادلة الكيميائية التي تمثل ما شاهدته. وضح كيف تميز معملياً بين الإيثان CH3 – CH3 والإيثين CH2 = CH2 بكاشف البروم Br2.	short_answer	\N	\N	\N	الكيمياء العضوية - التمييز بين المركبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	34	2026-06-23 11:16:51.447365+00
e4d40563-7ffa-44d7-90bc-7dc458649ee4	1d6bff6c-781b-4679-ac95-648f9ca208f9	مستعيناً بالمعادلات الكيميائية اذكر ما تشاهد ثم اكتب المعادلة الكيميائية التي تمثل ما شاهدته. وضح كيف تميز معملياً بين حمض إيثانويك CH3COOH وإستر إيثانوات الميثيل CH3COOCH3 مستخدماً فلز الصوديوم Na.	short_answer	\N	\N	\N	الكيمياء العضوية - التمييز بين المركبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	35	2026-06-23 11:16:51.447365+00
71a11d64-c71f-4e59-aa83-e21d9684f564	1d6bff6c-781b-4679-ac95-648f9ca208f9	مستعيناً بالمعادلات الكيميائية اذكر ما تشاهد ثم اكتب المعادلة الكيميائية التي تمثل ما شاهدته. وضح كيف تميز معملياً بين الهكسين -1 CH2 = CH – CH2 – CH2 – CH2 – CH3 والبروم بإضافة البروم Br2.	short_answer	\N	\N	\N	الكيمياء العضوية - التمييز بين المركبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	36	2026-06-23 11:16:51.447365+00
d5190e9e-f599-4d73-85d8-b8df6e0fbf01	1d6bff6c-781b-4679-ac95-648f9ca208f9	للصيغة العضوية C6H5Br متشاكآن (أيزوميران)، اكتب الصيغة البنائية لكل منهما، وحدد نوع التشاكب بينهما.	short_answer	\N	\N	\N	الكيمياء العضوية - المتشاكبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	37	2026-06-23 11:16:51.447365+00
8e5fad08-993e-471f-aee2-7d6be5d047ba	1d6bff6c-781b-4679-ac95-648f9ca208f9	صيغة متشاكب (١):	short_answer	\N	\N	\N	الكيمياء العضوية - المتشاكبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	38	2026-06-23 11:16:51.447365+00
0bddb8f6-48a8-4e44-98ee-e4f4f15a38a5	1d6bff6c-781b-4679-ac95-648f9ca208f9	صيغة متشاكب (٢):	short_answer	\N	\N	\N	الكيمياء العضوية - المتشاكبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	39	2026-06-23 11:16:51.447365+00
31985349-2eb8-465e-af6a-75ceb998d1ff	1d6bff6c-781b-4679-ac95-648f9ca208f9	نوع التشاكب بينهما:	short_answer	\N	\N	\N	الكيمياء العضوية - المتشاكبات	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	40	2026-06-23 11:16:51.447365+00
0bab7861-c64c-4846-a74d-68846e764f62	1d6bff6c-781b-4679-ac95-648f9ca208f9	للتفاعل 2A + 2B —> C، إذا كان معدل (سرعة) التفاعل يساوي 1.75 × 10^-5 مول / دم3 .ث بالنسبة لاستهلاك المادة (A)، كم يكون معدل تكون (C)؟	calculation	\N	\N	\N	سرعة التفاعل الكيميائي	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	41	2026-06-23 11:16:51.447365+00
c94a393a-a454-49e1-9685-f6a32f09a50c	1d6bff6c-781b-4679-ac95-648f9ca208f9	ماذا يقصد بالعامل الحفاز؟	short_answer	\N	\N	\N	الحفز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	42	2026-06-23 11:16:51.447365+00
00758bd5-7090-4e58-b968-b4af9e61570d	1d6bff6c-781b-4679-ac95-648f9ca208f9	ما هو الحفز المتجانس؟	short_answer	\N	\N	\N	الحفز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	43	2026-06-23 11:16:51.447365+00
6be32630-355b-457d-b458-620b97a60add	1d6bff6c-781b-4679-ac95-648f9ca208f9	العامل الحفاز هو:	short_answer	\N	\N	\N	الحفز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	44	2026-06-23 11:16:51.447365+00
d9c8e749-7bf5-4f81-9330-a738223ef11c	1d6bff6c-781b-4679-ac95-648f9ca208f9	الحفز المتجانس هو:	short_answer	\N	\N	\N	الحفز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	45	2026-06-23 11:16:51.447365+00
bdef546c-9b61-4bb2-93d4-a16bda4e8b95	1d6bff6c-781b-4679-ac95-648f9ca208f9	2.56 جم من الميثانول CH3OH أذيبت في الماء، وأكمل حجم المحلول إلى 100 سم3. كثافة المحلول = 0.90 جم/سم3. كم يكون تركيز المحلول بالمول / دم3؟ (الكتلة الجزيئية لـ CH3OH = 32)	calculation	\N	\N	\N	المحاليل - التركيز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	46	2026-06-23 11:16:51.447365+00
dbc9302d-ab19-46ab-bdaa-a62f8f9b9ce0	1d6bff6c-781b-4679-ac95-648f9ca208f9	2.56 جم من الميثانول CH3OH أذيبت في الماء، وأكمل حجم المحلول إلى 100 سم3. كثافة المحلول = 0.90 جم/سم3. كم تكون النسبة المئوية (بالكتلة) للميثانول في المحلول؟ (الكتلة الجزيئية لـ CH3OH = 32)	calculation	\N	\N	\N	المحاليل - التركيز	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	47	2026-06-23 11:16:51.447365+00
9d2f1200-eeb2-413b-a815-aa5b19b6c019	1d6bff6c-781b-4679-ac95-648f9ca208f9	كيف تحضر 750 سم3 من محلول H2SO4 تركيزه 0.50 م من حمض الكبريتيك المخفف في المعمل المدرسي تركيزه 2.50 م؟	mcq	["أ- بمزج 250.0 سم3 من المحلول المخفف مع 500.0 سم3 من الماء.", "ب- بمزج 150.0 سم3 من المحلول المخفف مع 600.0 سم3 من الماء.", "ت- بمزج 600.0 سم3 من المحلول المخفف مع 150.0 سم3 من الماء.", "ث- بمزج 375.0 سم3 من المحلول المخفف مع 375.0 سم3 من الماء."]	\N	\N	المحاليل - التخفيف	\N	chemistry	grade12	sudan	\N	final	\N	\N	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022	48	2026-06-23 11:16:51.447365+00
\.


--
-- Data for Name: exam_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_records (exam_id, curriculum_doc_id, title, book_title, subject, grade, country, track, year, exam_type, organization, owner_id, visibility, question_count, extraction_status, extraction_error, extracted_at, ocr_quality_score, extraction_attempts, failure_reason, ocr_diagnostics, created_at, updated_at) FROM stdin;
1d6bff6c-781b-4679-ac95-648f9ca208f9	1d6bff6c-781b-4679-ac95-648f9ca208f9	إمتحان الكيمياء 2022.pdf	\N	chemistry	grade12	sudan		\N	final	\N	JlLBDDgQpkRtgJ3efZ8Lp7yhijr2	private	48	done	\N	2026-06-23 11:16:51.454+00	\N	\N	\N	\N	2026-06-23 11:16:51.419231+00	2026-06-23 11:16:51.456401+00
fb270347-276f-4b14-bdb6-01d23076a627	fb270347-276f-4b14-bdb6-01d23076a627	إمتحان الأحياء 2022 (1).pdf	\N	biology	grade12	sudan		\N	final	\N	JlLBDDgQpkRtgJ3efZ8Lp7yhijr2	private	0	pending	Daily Gemini quota exhausted — will retry on next server restart	\N	\N	\N	\N	\N	2026-06-23 11:16:51.425123+00	2026-06-23 12:27:25.346078+00
4fa330de-ddcd-47dc-9dd2-9c6b11fed943	4fa330de-ddcd-47dc-9dd2-9c6b11fed943	إمتحان الأحياء 2024.pdf	\N	biology	grade12	sudan		\N	final	\N	JlLBDDgQpkRtgJ3efZ8Lp7yhijr2	private	0	pending	Daily Gemini quota exhausted — will retry on next server restart	\N	\N	\N	\N	\N	2026-06-23 11:16:51.4291+00	2026-06-23 19:26:23.708263+00
\.


--
-- Data for Name: pdf_upload_hashes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pdf_upload_hashes (sha256, doc_id, owner_id, uploaded_at) FROM stdin;
\.


--
-- Data for Name: rate_limit_buckets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rate_limit_buckets (id, tokens, last_refill_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (uid, role, granted_by, created_at) FROM stdin;
\.


--
-- Data for Name: weakness_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.weakness_snapshots (id, student_id, country, grade, subject, topic_scores, total_exams, last_updated) FROM stdin;
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 2, true);


--
-- Name: db_backup_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.db_backup_log_id_seq', 2, true);


--
-- Name: weakness_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.weakness_snapshots_id_seq', 1, false);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: db_backup_log db_backup_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.db_backup_log
    ADD CONSTRAINT db_backup_log_pkey PRIMARY KEY (id);


--
-- Name: exam_answers exam_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_answers
    ADD CONSTRAINT exam_answers_pkey PRIMARY KEY (id);


--
-- Name: exam_attempts exam_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_attempts
    ADD CONSTRAINT exam_attempts_pkey PRIMARY KEY (id);


--
-- Name: exam_questions exam_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_questions
    ADD CONSTRAINT exam_questions_pkey PRIMARY KEY (id);


--
-- Name: exam_records exam_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_records
    ADD CONSTRAINT exam_records_pkey PRIMARY KEY (exam_id);


--
-- Name: pdf_upload_hashes pdf_upload_hashes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pdf_upload_hashes
    ADD CONSTRAINT pdf_upload_hashes_pkey PRIMARY KEY (sha256);


--
-- Name: rate_limit_buckets rate_limit_buckets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rate_limit_buckets
    ADD CONSTRAINT rate_limit_buckets_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (uid, role);


--
-- Name: weakness_snapshots weakness_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weakness_snapshots
    ADD CONSTRAINT weakness_snapshots_pkey PRIMARY KEY (id);


--
-- Name: weakness_snapshots weakness_snapshots_student_id_country_grade_subject_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weakness_snapshots
    ADD CONSTRAINT weakness_snapshots_student_id_country_grade_subject_key UNIQUE (student_id, country, grade, subject);


--
-- Name: exam_answers_attempt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_answers_attempt_idx ON public.exam_answers USING btree (attempt_id);


--
-- Name: exam_answers_question_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_answers_question_idx ON public.exam_answers USING btree (question_id);


--
-- Name: exam_attempts_exam_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_attempts_exam_idx ON public.exam_attempts USING btree (exam_id);


--
-- Name: exam_attempts_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_attempts_status_idx ON public.exam_attempts USING btree (student_id, status);


--
-- Name: exam_attempts_student_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_attempts_student_idx ON public.exam_attempts USING btree (student_id);


--
-- Name: exam_questions_exam_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_questions_exam_idx ON public.exam_questions USING btree (exam_id);


--
-- Name: exam_questions_search_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_questions_search_idx ON public.exam_questions USING btree (country, grade, subject, question_order);


--
-- Name: exam_questions_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_questions_type_idx ON public.exam_questions USING btree (exam_id, question_type);


--
-- Name: exam_records_curriculum_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_records_curriculum_idx ON public.exam_records USING btree (curriculum_doc_id);


--
-- Name: exam_records_owner_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_records_owner_idx ON public.exam_records USING btree (owner_id);


--
-- Name: exam_records_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exam_records_status_idx ON public.exam_records USING btree (extraction_status);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_action ON public.audit_log USING btree (action);


--
-- Name: idx_audit_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_created_at ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_audit_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_uid ON public.audit_log USING btree (uid);


--
-- Name: idx_puh_owner; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_puh_owner ON public.pdf_upload_hashes USING btree (owner_id);


--
-- Name: idx_rlb_updated; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_rlb_updated ON public.rate_limit_buckets USING btree (updated_at);


--
-- Name: idx_user_roles_uid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_roles_uid ON public.user_roles USING btree (uid);


--
-- Name: weakness_snapshots_student_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX weakness_snapshots_student_idx ON public.weakness_snapshots USING btree (student_id);


--
-- Name: exam_answers exam_answers_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_answers
    ADD CONSTRAINT exam_answers_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES public.exam_attempts(id) ON DELETE CASCADE;


--
-- Name: exam_answers exam_answers_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_answers
    ADD CONSTRAINT exam_answers_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.exam_questions(id);


--
-- Name: exam_attempts exam_attempts_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_attempts
    ADD CONSTRAINT exam_attempts_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exam_records(exam_id) ON DELETE CASCADE;


--
-- Name: exam_questions exam_questions_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_questions
    ADD CONSTRAINT exam_questions_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exam_records(exam_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Ng8haDwfsRowZi7r5sZtuxcyF9EeVC0Ka4vfV2Tcjas31wYeDLqAqTEVBD1NidB

